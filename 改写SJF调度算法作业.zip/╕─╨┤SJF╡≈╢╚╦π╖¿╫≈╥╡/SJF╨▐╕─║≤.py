class Job:
    def __init__(self, name, arrival_time, execution_time):
        self.name = name  # 作业名称
        self.arrival_time = arrival_time  # 作业到达时间
        self.execution_time = execution_time  # 作业执行时间


def sjf_scheduling(job_list):
    # 根据作业到达时间进行排序
    job_list.sort(key=lambda x: (x.arrival_time, x.execution_time))

    # 初始化等待时间和总等待时间
    waiting_time = 0
    total_waiting_time = 0

    # 遍历作业列表
    for i, job in enumerate(job_list):
        print("Running Job {} for {} seconds...".format(job.name, job.execution_time))
        # 计算每个作业的等待时间
        waiting_time += job.execution_time
        total_waiting_time += waiting_time - job.arrival_time

    # 计算平均等待时间
    avg_waiting_time = total_waiting_time / len(job_list)
    print("Average waiting time: {:.2f} seconds".format(avg_waiting_time))


def main():
    # 创建三个作业实例
    job1 = Job("A", 0, 3)
    job2 = Job("B", 1, 1)
    job3 = Job("C", 2, 2)

    # 将作业实例添加到列表中
    job_list = [job1, job2, job3]

    print("=== SJF Scheduling ===")
    print("Initial Job Queue:")
    for job in job_list:
        print("Job {}: Arrival Time - {}, Execution Time - {} seconds".format(job.name, job.arrival_time,
                                                                              job.execution_time))

    # 执行 SJF 调度算法
    sjf_scheduling(job_list)


if __name__ == "__main__":
    main()